﻿namespace DreamBit.Game.Elements.Components
{
    public class ScriptBehavior
    {
    }
}
