﻿using DreamBit.Game.Elements;
using DreamBit.Game.Elements.Components;
using Microsoft.Xna.Framework;

namespace Game1.Scripts
{
    public class Player : ScriptBehavior
    {
        public string Name { get; set; }
        public int Life { get; set; }
        public bool IsAlive { get; set; }
        public int Defense { get; set; }
        public int Strength { get; set; }
        public int Dexterity { get; set; }
        public int Intelligence { get; set; }
        public Vector2 Speed { get; set; }
        public GameObject Camera { get; set; }
    }
}