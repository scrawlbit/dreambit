﻿using DreamBit.Game.Elements.Components;

namespace Game1.Scripts
{
    public class Boss : ScriptBehavior
    {
    }
}