﻿namespace Game1.Scripts
{
    public class ParticleManager
    {
    }
}